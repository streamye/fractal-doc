#!/bin/bash
# start
# url

CURDIR=$(cd $(dirname ${BASH_SOURCE[0]}); pwd )
echo $CURDIR 
export LD_LIBRARY_PATH=$CURDIR
echo $LD_LIBRARY_PATH



b="del"
c="stop"
d="check"
if [ "$1"x == "$b"x ]
then
   echo "delete all files"
   killall -9 gftl
   rm gftl.log
 
   rm -rf data1/
   
   echo "delete succeed"
elif [ "$1"x == "$c"x ]
then
	killall -9 gftl
	echo "gftl stopped"
elif [ "$1"x == "$d"x ]
then
	curl -H "Content-Type:application/json" -X POST --data '{"jsonrpc": "2.0","id": "1","method": "ftl_headBlock"}' http://127.0.0.1:8545/rpc

else
	killall -9 gftl
	myFile="genesis_alloc_official.json"
	datadir="data1"
	if [ ! -d "$datadir" ]; then 
		mkdir data1
		./gtool keys --keys data1/keys --pass 666 newkeys    
	fi 	
	nohup ./gftl --config test.toml --genesisAlloc genesis_alloc_official.json --rpc --rpcport 8545 --datadir data1 --port 30303 --pprof --pprofport 6060 --verbosity 3 --mine --unlock 666 --bootnodes enode://2b36b97ea62b8ff41011223ff0720db7e468500e2aa3253668f13a9ecd15fbbd5c1ccce8252712c063cd166f1f7be95747574cf6a68d9726a3fad62cdb40f34e@127.0.0.1:30303 > gftl.log 2>&1 & 
echo "gftl started"
fi

