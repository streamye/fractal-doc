#!/bin/bash
# start
# url

CURDIR=$(cd $(dirname ${BASH_SOURCE[0]}); pwd )
echo $CURDIR 
export LD_LIBRARY_PATH=$CURDIR
echo $LD_LIBRARY_PATH



b="del"
c="stop"
d="check"
if [ "$1"x == "$b"x ]
then
   echo "delete all files"
   killall -9 gftl
   rm gftl.log
 
   rm -rf data1/
   rm -rf data2/
   rm -rf data3/
   rm -rf data4/
   rm -rf data5/
   rm -rf genesis_alloc.json
   echo "delete succeed"
elif [ "$1"x == "$c"x ]
then
	killall -9 gftl
	echo "gftl stopped"
elif [ "$1"x == "$d"x ]
then
	curl -H "Content-Type:application/json" -X POST --data '{"jsonrpc": "2.0","id": "1","method": "ftl_headBlock"}' http://127.0.0.1:8545/rpc

else
	killall -9 gftl
	myFile="genesis_alloc.json"
	if [ ! -f "$myFile" ]; then 
		 mkdir data1
		mkdir data1
		mkdir data2
		mkdir data3 
		mkdir data4  
		mkdir data5 
		./gtool keys --keys data1/keys --pass 666 newkeys
		./gtool keys --keys data2/keys --pass 666 newkeys  
		./gtool keys --keys data3/keys --pass 666 newkeys  
		./gtool keys --keys data4/keys --pass 666 newkeys  
		./gtool keys --keys data5/keys --pass 666 newkeys     
	
		./gtool gstate --pass 666 gen
	fi 	

	nohup ./gftl --config test.toml --genesisAlloc genesis_alloc.json --rpc --rpcport 8545 --datadir data1 --port 30303 --pprof --pprofport 6060 --verbosity 3 --mine --unlock 666 > gftl.log 2>&1 & 
echo "gftl started"
fi

