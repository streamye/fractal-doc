#!/bin/bash
# start
# url

CURDIR=$(cd $(dirname ${BASH_SOURCE[0]}); pwd )
echo $CURDIR 
export DYLD_LIBRARY_PATH=$CURDIR
echo $DYLD_LIBRARY_PATH

killall -9 gftl

b="del"
c="stop"
if [ "$1"x == "$b"x ]
then
   echo "delete all files"
   
   rm gftl.log
 
   rm -rf data1/
   rm -rf data2/
   rm -rf data3/
   rm -rf data4/
   rm -rf data5/
   rm -rf genesis_alloc.json
   echo "delete succeed"
elif [ "$1"x == "$c"x ]
then
	echo "gftl stopped"
else
	myFile="genesis_alloc.json"
	if [ ! -f "$myFile" ]; then 
		 mkdir data1
		mkdir data1
		mkdir data2
		mkdir data3 
		mkdir data4  
		mkdir data5 
		./gtool keys --keys data1/keys --pass 666 newkeys
		./gtool keys --keys data2/keys --pass 666 newkeys  
		./gtool keys --keys data3/keys --pass 666 newkeys  
		./gtool keys --keys data4/keys --pass 666 newkeys  
		./gtool keys --keys data5/keys --pass 666 newkeys     
	
		./gtool gstate --pass 666 gen
	fi 	

	nohup ./gftl --config test.toml --genesisAlloc genesis_alloc.json --rpc --rpcport 8545 --datadir data1 --port 30303 --pprof --pprofport 6060 --verbosity 3 --mine --unlock 666 > gftl.log & 
echo "gftl started"
fi

